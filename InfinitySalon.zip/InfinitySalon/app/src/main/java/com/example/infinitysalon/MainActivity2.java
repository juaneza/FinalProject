package com.example.infinitysalon;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    DrawerLayout drawerLayout;
    ImageView image1, image2, image3, image4, image5, image6, image7;
    Dialog myDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        myDialog = new Dialog(this);

        drawerLayout = findViewById(R.id.drawer_layout);

    }

    public void waxing(View view) {
        myDialog.setContentView(R.layout.waxing);

        image1 = (ImageView) findViewById(R.id.image1);

        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();

    }

    public void threading(View view) {
        myDialog.setContentView(R.layout.threading);

        image2 = (ImageView) findViewById(R.id.image2);

        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();

    }

    public void facial(View view) {
        myDialog.setContentView(R.layout.facial);

        image3 = (ImageView) findViewById(R.id.image3);

        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();

    }

    public void massage(View view) {
        myDialog.setContentView(R.layout.massage);

        image4 = (ImageView) findViewById(R.id.image4);

        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();

    }

    public void eyebrowtinting(View view) {
        myDialog.setContentView(R.layout.eyebrowtinting);

        image5 = (ImageView) findViewById(R.id.image5);

        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();

    }

    public void manicure(View view) {
        myDialog.setContentView(R.layout.manicure);

        image6 = (ImageView) findViewById(R.id.image6);

        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();

    }

    public void pedicure(View view) {
        myDialog.setContentView(R.layout.pedicure);

        image7 = (ImageView) findViewById(R.id.image7);

        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();

    }


    public void ClickMenu(View view){
        openDrawer(drawerLayout);


    }

    static void openDrawer(DrawerLayout drawerLayout){
        drawerLayout.openDrawer(GravityCompat.START);

    }

    public void ClickLogo(View view){
        closeDrawer(drawerLayout);


    }

    public static void closeDrawer(DrawerLayout drawerLayout) {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    public void ClickHome(View view){
        recreate();

    }
    public void ClickList(View view){
        redirectActivity(this,Pricelist.class);

    }

    public void ClickExit(View view){
       exit(this);
    }

    public static void exit(final Activity activity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Exit");
        builder.setMessage("Are You Sure You Want To Exit?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                activity.finishAffinity();

                System.exit(0);

            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();
    }

    public static void redirectActivity(Activity activity,Class aClass) {
        Intent intent = new Intent(activity,aClass);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        activity.startActivity(intent);
    }

    @Override
    protected void onPause() {
        super.onPause();
        closeDrawer(drawerLayout);
    }
}